# HOODSCOUT / ROBINHOOD CHAIN

**Standalone, Robinhood Chain-only** Uniswap V3 pool scanner, Jev-compatible decision bridge, independent risk gates, paper-trading ledger, research replay, and monochrome dashboard. **Not related to or built into the existing Solana bot.**

**Status:** research MVP; live order broadcasting intentionally unimplemented / blocked. Read-only chain ID, contract getters and a QuoterV2 call were verified on Robinhood mainnet on 2026-10-09. No profitable strategy or live trading readiness is claimed. Sample dashboard data is **synthetic**, clearly labeled, and isolated in `data/demo`.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
cp .env.example .env                  # only if .env does not already exist; configure QUOTER_V2_ADDRESS
hoodscout serve
# open http://127.0.0.1:8000
```

Python 3.11+ required. For a dashboard with *no* network calls (empty local ledger):

```bash
hoodscout serve --no-scan
```

For a populated, **explicitly synthetic** visual preview:

```bash
hoodscout demo
DATA_DIR=./data/demo hoodscout serve --no-scan
```

Scanner-only CLI: `hoodscout scan`. Run historical replay analyses: `hoodscout backtest --entry-second 60 --hold-seconds 300`.

## Data flow

```text
Robinhood Chain JSON-RPC 4663
         │
         ▼
Uniswap V3 Factory PoolCreated (block-aware polling, persistent cursor)
         │
         ▼
ERC-20 contract state + slot0 + pool balances (WETH pairs)
         │
         ▼
QuoterV2 eth_call (optional, verified address required)
         │
         ▼
Snapshots → external Jev-compatible decision → hard risk gates
         │                              │
         └── SQLite / JSONL audit      └── PAPER ledger (only when all gates pass)
                                                  │
                                                  ▼
                                       Web dashboard + replay API
```

The startup RPC check fails closed if the endpoint doesn't report Robinhood mainnet chain ID `4663`. Factory scans are bounded by `MAX_BLOCK_RANGE` to accommodate rate-limited RPCs and persist the last successful block. Event timestamps are derived from blocks; the first scan defaults to the latest `BACKFILL_BLOCKS` blocks, so this is **not full historic indexing**.

## Main contracts / references

- Network: `https://rpc.mainnet.chain.robinhood.com`; chain ID `4663`; native gas ETH.
- Uniswap V3 Factory: `0x1f7d7550B1b028f7571E69A784071F0205FD2EfA`.
- WETH: `0x0Bd7D308f8E1639FAb988df18A8011f41EAcAD73`.
- **QUOTER_V2_ADDRESS must be verified and configured**. Independently documented candidate `0x33e885eD0Ec9bF04EcfB19341582aADCb4c8A9E7`. A non-empty code check alone doesn't prove the quoter is authentic; verify source and its factory before trading.
- References: [Robinhood official network docs](https://docs.robinhood.com/chain/connecting/); [third-party contract registry](https://docs.hoodl.app/robinhood-chain/).

**IMPORTANT about liquidity:** Spot price is read from Uniswap V3 `slot0`, properly scaled for ERC-20 decimals. Pool token balances can derive an approximate USD TVL **only for WETH pairs when the timestamped Coinbase/Kraken ETH/USD reference passes validation**. This is *not executable depth*. The risk gates additionally demand a successful QuoterV2 quote for the intended paper order and price impact under the configured threshold. `liquidity_usd` in snapshot states is a TVL proxy and only filled after such a quote; it is NOT the value one can necessarily withdraw or sell. A trustworthy live ETH/USD oracle, high-quality fill simulation and verification of WETH reserve reliability are needed before relying on any result. No actual stable-coin/non-WETH USD valuations are made.

**IMPORTANT about ownership:** `owner()` is optional and a nonstandard assumption for many ERC-20s. If absent, ownership is `null`, not `false`. Default gates reject unknown or non-renounced contracts. Even renouncement does NOT mean scam-free or sellable. There is not yet a token honeypot detector.

## Jev decision model

Default `DECISION_PROVIDER=stub`: returns **HOLD** and risk score 10 for every observation. Therefore the scanner can discover pools, observe prices and log decisions but **cannot generate fake buys without a model**.

To enable the supplied third-party Jev adapter:

```dotenv
DECISION_PROVIDER=jev
TYPESAFE_API_KEY=your_secret_key
```

The adapter sends `state`, `questions` and `model=jev-latest` to `https://api.typesafe.ai/v1/systemone` using the contract in the official TypeSafe SDK 0.7.4. Score questions require an ordered `criteria` list. JEV scores that list from 0 to 9; HoodScout converts it to risk 1 to 10. The lower of action confidence and risk confidence is used by the confidence gate. Malformed/error responses fail closed to HOLD. Request/response fixtures were checked against the SDK OpenAPI models, but a real authenticated call must still pass on your machine. The dashboard never exposes the key.

The hard gates operate **after** the model and independently check min TVL proxy ($20K), verified fresh quoter execution quote, strictly less than 3% quote impact, observed 1–100% trailing volatility, at least 3 unique buyers, top buyer at most 50% of buy volume, swap data no older than 30 seconds, min confidence 0.70, max risk score 4, renounced ownership and real bytecode. Also, `LIVE_MODE=true` is **not sufficient to trade**: the live executor refuses to send any transaction in this release. No real private keys required or accepted.

## Research replay

Snapshots are recorded **when observed**; the bot does not fabricate historical ticks. For a requested entry at T+60 seconds and holding 300 seconds, the replay requires actual time-appropriate snapshots at the entry and exit. It omits incomplete tokens, reporting how many were usable. Simple replay net return includes an explicit fee/slippage haircut on each side but not chain gas, latency, MEV, taxes, or guaranteed historical fillability. Use only as preliminary research.

API endpoints:

- `GET /api/state`: full dashboard state (incl. paper ledger, decisions, recent launch feed).
- `GET /api/stream`: server-sent event updates.
- `GET /api/replay?pool=0x...&entry_second=60&hold_seconds=300`.
- `GET /api/backtest?entry_second=60&hold_seconds=300`.

Persisted files under `DATA_DIR`:

- `hoodscout.db` — SQLite pool events, snapshots, decisions, paper positions and persistent cursor.
- `decisions.jsonl` — append-only normalized+raw model audit records with full states.

## Operational limitations (read before using)

1. **Read-only scanning + paper mode.** Live broadcasting is deliberately unavailable; this project is not a functioning live sniper.
2. **Launch detection is pool creation, not token contract deployment**; a pool can appear uninitialized or receive liquidity later.
3. **Swap activity covers watched pools only.** Buyers/sellers come from decoded Uniswap V3 Swap events of pools in the active watch list, identified by transaction sender. There is no wallet clustering, bot labelling or holder-balance indexing; `holder_concentration` stays `null`.
4. **No historical backfill of months of tokens.** Start on the live stream; restore limited recent pool state from SQLite after restart.
5. **Research price reference, not an on-chain oracle.** Coinbase and Kraken last-trade prices are refreshed and cross-checked. Both must be fresh. Exchange prices do not prove bridged WETH redeemability, chain-local USD value or executable sell prices. Static `ETH_USD` is ignored by the scanner.
6. **A quote is not sellability proof.** The current MVP does not simulate a complete buy/approve/sell round trip or handle fee-on-transfer tokens.
7. **Jev remains unverified.** Mainnet RPC/getters and a real QuoterV2 call were checked; the sampled pool exceeded the price-impact limit. Coinbase was checked on Windows. The cloud proxy currently blocks exchange-feed requests, so live combined Coinbase/Kraken operation still requires validation in the target environment.
8. **Default binding is localhost.** Never expose the unauthenticated dashboard or API publicly without access control.
9. **Research stop/take-profit is spot-derived**, not an executable sell quote, and excludes gas/MEV. Paper P&L may overstate attainable results.
10. The current scanner has no optimized throughput for extremely high launch rates; use an indexed data source/robust provider before scaling.

## Swap activity tracking

For every watched WETH pool the scanner reads Uniswap V3 `Swap` events (`0xc42079f9…ca67`) in the same bounded block chunks as pool discovery, so a pool discovered by the scanner has swap history from its creation block. Swaps are stored in SQLite and deduplicated by pool, block and log index, which makes restarts and overlapping reads harmless. The transaction sender of each swap (`eth_getTransactionByHash`) identifies the trader, because the `sender` field of a Swap is usually a router. Lookups are bounded by `MAX_TX_LOOKUPS_PER_CYCLE` and catch up over later cycles.

Each snapshot records, using only swaps from blocks the scanner had fully read by then: buy/sell counts, WETH and USD buy/sell volume, net flow, unique buyers/sellers/traders, swaps per minute, peak swaps per second, buys and unique buyers in the last 30 seconds versus the 30 seconds before (buyer acceleration), top and top-3 buyer share of buy volume, wallets that both bought and sold, same-block round trips, and the 60-second realized price range from post-swap prices. When complete swap history exists, that swap-based range replaces the coarser snapshot-based `volatility_pct` (`volatility_source` says which one was used).

Wallet metrics are withheld (`null`) while any affected swap still has an unresolved sender, and concentration and swap-based volatility require complete history since pool creation. `activity_lag_seconds` measures how far the recorded swaps trail the observation. The gates reject unknown, stale or concentrated activity: `MIN_UNIQUE_BUYERS=3`, `MAX_TOP_BUYER_SHARE_PCT=50`, `ACTIVITY_MAX_LAG_SECONDS=30`. Each extra watched pool adds no extra log request; each new transaction adds one sender lookup.

## JEV credits, kill switch and replay statistics

`JEV_CALL_POLICY=prefiltered` (default) sends a pool to JEV only when every non-model gate would already approve the strongest possible model answer. If a deterministic gate fails, no model answer could approve an entry, so no credits are spent; the audit record then shows `sent: false` and the blocking reasons. `JEV_CALL_POLICY=all` restores one call per 30-second decision window for research.

The dashboard **KILL SWITCH** button (or `POST /api/kill-switch` with `{"enabled": true}` and header `X-HoodScout-Control: 1`) immediately blocks JEV calls and every new paper entry, and survives restarts because it is stored in the database. Existing paper positions continue to be marked and closed. When `HOST` is a loopback address the server rejects requests whose `Host` header is not `127.0.0.1`/`localhost`, which stops DNS-rebinding pages from using the local API.

Replay/backtest summaries now report expectancy per trade, total cost haircut, maximum drawdown of the cumulative net P&L, exclusions by reason, and an in-sample versus chronological-holdout split (latest 30% of usable trades). No parameters are fitted, so the holdout is only a stability check.

## Tests

```bash
PYTHONPATH=src pytest -q
```

GitHub Actions (`.github/workflows/ci.yml`) runs the suite on Linux and Windows with Python 3.11–3.13. The tests use only synthetic fixtures and mocks; they never contact the chain, exchanges or JEV.

## UX

Monochrome interface inspired by the supplied screenshot: left session P&L, KPI header and equity history, right activity log, and five bottom status modules (SCOUT, LEDGER, PULSE, FLUX, WARDEN). Demo data cannot be mistaken for real P&L: `SYNTHETIC DEMO` is displayed in the header.


## Price-feed and discovery update

The scanner uses the canonical Uniswap V3 `PoolCreated` topic. Older builds used an incorrect topic; an online scanner did not prove that any launches were discovered. On first start after this update a new `pool_created_cursor_v2` starts a bounded `BACKFILL_BLOCKS` window. Subsequent starts resume that cursor. Existing events, paper positions, decisions and databases are preserved. This does not recover all earlier missed launches. Increase `BACKFILL_BLOCKS` before the first updated run if a larger recovery window is required; do not delete databases to reset a cursor. RPC queries remain bounded by `MAX_BLOCK_RANGE`.

Default price settings (no API keys):

```dotenv
PRICE_FEED_MODE=coinbase_kraken
PRICE_REFRESH_SECONDS=10
PRICE_MAX_AGE_SECONDS=60
PRICE_MAX_DIVERGENCE_PCT=1
PRICE_FUTURE_TOLERANCE_SECONDS=5
QUOTE_MAX_AGE_SECONDS=15
```

Coinbase Exchange `GET /products/ETH-USD/ticker` supplies the primary USD last-trade price. Kraken `GET /0/public/Trades?pair=ETHUSD&count=1` supplies an independent last trade. The oldest trade timestamp controls freshness. Symmetric percentage disagreement uses the mean of both prices as denominator. Missing/malformed data, HTTP failures, nonfinite values, future timestamps and stale trades invalidate the reference. There is no static or single-source fallback. A failed refresh immediately discards the prior price; cached data also expires between refreshes. `PRICE_FEED_MODE=off` disables USD valuations and entry eligibility.

Snapshots and JSONL decisions record both sources, their timestamps, reference price and disagreement. Risk gates recheck reference and quote age after the model responds. A quote at or above the price-impact limit is rejected. USD paper marks are withheld when the reference expires; existing positions remain open until usable observations return. Spot-derived exits still have the limitations listed above.

Network access is needed for `rpc.mainnet.chain.robinhood.com`, `api.exchange.coinbase.com` and `api.kraken.com`. The dashboard exposes `price_feed` in `/api/state` and shows either the cross-checked price/ages or the blocking reason. Neither a configured key nor an open HTTP port proves the model/scanner/feed works.

For Windows, keep the existing `.env`, stop the old server with Ctrl+C, then from the project PowerShell terminal run:

```powershell
$env:DATA_DIR = './data/paper'
$env:LIVE_MODE = 'false'
$env:DECISION_PROVIDER = 'stub'
$env:PRICE_FEED_MODE = 'coinbase_kraken'
$env:QUOTER_V2_ADDRESS = '0x33e885eD0Ec9bF04EcfB19341582aADCb4c8A9E7'
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\hoodscout.exe serve
```

The Quoter address matches Uniswap's sdk-core Robinhood registry and returned the configured factory/WETH and a valid quote at block 84278943. This is functional evidence, not a bytecode audit or token sellability proof. Each running monitor checks its factory/WETH before quoting. Previously rejected Quoters remain rejected. Quotes are requested only for observed initialized WETH pools with validated reference prices.

Keep the stub until a decision provider is separately validated. This update does not fabricate buy activity, implement Swap tracking or automatically enable entries. Live broadcasting remains unavailable.


## JEV setup and connection diagnostics

**Two routes to JEV.** `JEV_ROUTE=auto` (default) uses Vercel AI Gateway when a gateway key is configured, otherwise TypeSafe directly:

| Route | Key in `.env` | Endpoint | Model | Billing |
| --- | --- | --- | --- | --- |
| `vercel` | `VERCEL_TYPESAFE_API_KEY` (also `AI_GATEWAY_API_KEY`) | `https://ai-gateway.vercel.sh/typesafe/v1/systemone` | `typesafe-ai/jev` (`VERCEL_JEV_MODEL`) | your Vercel AI Gateway account |
| `typesafe` | `TYPESAFE_API_KEY` | `https://api.typesafe.ai/v1/systemone` | `jev-latest` (`JEV_MODEL`) | TypeSafe credits |

Both use the same TypeSafe System One request and response, per Vercel's [TypeSafe API with AI Gateway](https://vercel.com/docs/ai-gateway/sdks-and-apis/typesafe) docs. The endpoint is derived from the route, so a key is never sent to the other service; `JEV_ENDPOINT` is no longer used. A gateway key set in the Windows environment (`AI_GATEWAY_API_KEY`) is used when `.env` has none. After a successful check, setup writes `JEV_ROUTE` to `.env` so the server uses the same route. Vercel-route errors are explained in Vercel terms (401 key, 402 billing, 403 team access, which Vercel may tie to a payment method on file). The Vercel route was implemented from Vercel's documentation and tested against mocked responses; it has not been called live from the build environment.

Obtain an API key from your own TypeSafe account at https://typesafe.ai. API inference may require account credits. Do not paste keys into chat, GitHub or command-line arguments.

Put the key into the project `.env` as `TYPESAFE_API_KEY=your-key` (VS Code or Notepad; no quotes needed). Then, from the project directory, run `.venv\Scripts\python.exe -m hoodscout.cli jev-setup` on Windows (or `.venv/bin/python -m hoodscout.cli jev-setup` on Linux). Nothing is typed or pasted into the terminal: setup reads the key from `.env`. If it is missing, setup adds an empty `TYPESAFE_API_KEY=` line and, on Windows, opens `.env` in Notepad and continues after Notepad is closed. The `.env` key always wins over an older `TYPESAFE_API_KEY` set in the Windows environment. `.env` files saved as UTF-16 (PowerShell `>`/`Set-Content`) or with a BOM are read correctly; surrounding quotes, spaces and a pasted `Bearer ` prefix are removed; `JEV_API_KEY` is accepted as an alternative name. Setup prints where the key was found and its length, never the key. It then performs one small explicitly synthetic inference with no executor and sets `DECISION_PROVIDER=jev` only after a valid API response (rewriting `.env` as UTF-8, other entries preserved, atomic replacement). Failed checks leave the file unchanged. On HTTP 401/403 it also calls the free `GET /v1/models` endpoint to tell a rejected key (401 there too: create a new key) from a key without JEV access. Restart HoodScout afterward. No wallet key is used.

`hoodscout jev-check` makes the same no-trade connection check and returns a nonzero exit code on failure. It reports safe status codes for missing keys, 401 authentication failures, 402 credits/billing, 403 access, invalid request/model, rate limits, network errors, timeouts and invalid responses. It does not print credentials or raw error bodies. There are no automatic API retries that could multiply billable checks.

When the real scanner starts with `DECISION_PROVIDER=jev`, it performs one synthetic connection check. Real pool observations are sent only during the existing decision windows. Each API inference may consume credits. All existing independent liquidity, price, quote-age and risk gates remain active after a model BUY. The connectivity check itself never opens a position, regardless of the model's answer. Swap/buyer tracking is described below; wallet clustering and holder indexing are not implemented.

`/api/state` now includes `model_status`. `model_connected` becomes true only after an actual response is validated, not merely because a key exists. It clears after an error or when the most recent successful check is older than five minutes; that age limit does not assert the service is down and a subsequent request checks it again. Model health is in-process and must be rechecked after restart. `serve --no-scan` does not call JEV automatically.

The standard Windows launcher honors `.env` instead of overriding it with STUB. The dedicated JEV launcher performs the update, the `.env` key check and the restart. Avoid starting old launcher copies that still force STUB. Set `JEV_TIMEOUT_SECONDS` to adjust the request timeout; slow responses may expire the separate quote-age gate, which remains mandatory.

Contract reference: https://github.com/typesafe-ai/typesafe-sdk-python and https://pypi.org/project/typesafe-sdk/0.7.4/ . Verified wheel SHA-256: `61cf3f2fe9da20b68c3d3fe2fb76bbb2f35f8c4a9a65a6b81c43a535d2a53210`. This project uses its existing httpx dependency; installing the SDK is not required.
