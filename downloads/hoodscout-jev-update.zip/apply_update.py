"""Apply the HoodScout update without overwriting local edits or runtime data."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys


def digest(data):
    # A Windows checkout may have converted text files to CRLF.
    return hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()


def contained(root, name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name:
        raise ValueError(f'Unsafe update path: {name}')
    target = root.joinpath(*relative.parts)
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Update path escapes project: {name}')
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True, help='Existing HoodScout project directory')
    parser.add_argument('--check', action='store_true', help='Validate only; do not modify anything')
    args = parser.parse_args()
    root = args.project.resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / 'pyproject.toml').is_file() or not (root / 'src/hoodscout').is_dir():
        raise ValueError('Select the project folder containing pyproject.toml and src/hoodscout')
    manifest = json.loads((bundle / 'manifest.json').read_text(encoding='utf-8'))
    changes, conflicts = [], []
    for entry in manifest['files']:
        name = entry['path']
        if name == '.env' or name.startswith(('.venv/', 'data/')):
            raise ValueError('Update unexpectedly contains protected runtime files')
        target = contained(root, name)
        payload = contained(bundle / 'payload', name).read_bytes()
        if digest(payload) != entry['after']:
            raise ValueError(f'Update payload checksum mismatch: {name}')
        current = target.read_bytes() if target.is_file() else None
        if current is not None and digest(current) == entry['after']:
            continue
        before = entry['before'] if isinstance(entry['before'], list) else [entry['before']]
        if ((target.exists() and not target.is_file()) or
                (digest(current) if current is not None else None) not in before):
            conflicts.append(name)
        else:
            changes.append((name, target, payload, current))
    if conflicts:
        raise ValueError('Local changes or missing originals detected; nothing was changed:\n  ' +
                         '\n  '.join(conflicts) + '\nPreserve these files and resolve the changes manually.')
    if not changes:
        print('Update already applied. No files changed.')
        return
    print(f'{len(changes)} file(s) validated. .env, data and .venv are not part of this update.')
    if args.check:
        print('Validation only; no files changed.')
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup = root / 'hoodscout-update-backups' / stamp
    backup.mkdir(parents=True, exist_ok=False)
    for name, target, _, original in changes:
        if original is not None:
            saved = contained(backup, name)
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
    (backup / 'changes.json').write_text(json.dumps(
        [{'path': name, 'new_file': old is None} for name, _, _, old in changes], indent=2), encoding='utf-8')
    attempted = []
    try:
        for name, target, payload, original in changes:
            target.parent.mkdir(parents=True, exist_ok=True)
            attempted.append((name, target, original))
            target.write_bytes(payload)
    except BaseException:
        for name, target, original in reversed(attempted):
            if original is None:
                target.unlink(missing_ok=True)
            else:
                shutil.copy2(contained(backup, name), target)
        raise
    print(f'Update applied. Original files backed up to: {backup}')
    print('Next: run .venv Python with -m pytest -q, then -m hoodscout.cli jev-setup to verify JEV locally. Keep LIVE_MODE=false.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as exc:
        print(f'UPDATE STOPPED: {exc}', file=sys.stderr)
        raise SystemExit(1)
